class App {
  play() {
    console.log("app.play start");

    const MissionUtils = require("@woowacourse/mission-utils");
    console.log(MissionUtils.Random.pickNumberInRange(1,10))

    MissionUtils.Console.print('숫자 야구 게임을 시작합니다.')

    class Answer {
      constructor(){
        this.makeArr = MissionUtils.Random.pickUniqueNumbersInRange(1,9,3);
        this.makeNum = this.makeArr.join('');
      }
    }
    const answer = new Answer().makeNum;
    console.log(answer)
    const answerArr = new Answer().makeArr;


    if(answerArr.length < 3 ){
      throw new Error('3개 숫자만 입력');
    }
    MissionUtils.Console.readLine('숫자를 입력해주세요 : ', (answer) => {
      
      console.log(`${answer}`);
    });


  }
}

module.exports = App;
